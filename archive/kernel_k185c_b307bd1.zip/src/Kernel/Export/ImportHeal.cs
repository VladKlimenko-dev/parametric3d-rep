using OpenTK.Mathematics;
using Parametric3D.Kernel.Curves;
using Parametric3D.Kernel.Surfaces;
using Parametric3D.Kernel.Topology;

namespace Parametric3D.Kernel.Export;

/// <summary>
/// KRN-09 (09.5): ЛЕЧЕНИЕ ИМПОРТА В БЮДЖЕТЕ С ОТЧЁТОМ. Прочитанное тело приводится к соглашению о полурёбрах (иначе у него
/// нет точного объёма), затем:
/// <list type="number">
/// <item>вершина, отстоящая от поверхностей своих граней (точность записи другого CAD), — у плоских граней переносится в
/// пересечение трёх их плоскостей, рёбра-отрезки у неё перестраиваются; зазор больше бюджета — не лечится;</item>
/// <item>дыра в оболочке (контур свободных рёбер), лежащая в одной плоскости в пределах бюджета, — закрывается плоской
/// гранью «import:filled»;</item>
/// <item>итог проверяется (B-rep); негодное тело остаётся как прочитано и сообщается.</item>
/// </list>
/// Каждое действие и каждый отказ — строка отчёта; геометрия меняется только в пределах бюджета ToleranceContext.ImportHeal.
/// </summary>
public static class ImportHeal
{
    /// <summary>Мутация P3D_IMPORTHEAL=0: тело — как прочитано, без лечения и отчёта (прежде).</summary>
    public static readonly bool Off = Environment.GetEnvironmentVariable("P3D_IMPORTHEAL") == "0";

    public sealed record Report(double MaxVertexGap, int Snapped, int Filled, int OpenEdgesLeft, bool Valid, string? Problem)
    {
        public override string ToString() =>
            $"max vertex gap {MaxVertexGap:G3} mm, {Snapped} vertex(es) snapped, {Filled} hole(s) filled, {OpenEdgesLeft} open edge(s) left, " + (Valid ? "valid" : "NOT valid: " + Problem);
    }

    static Geometry.Ssi.Plane? PlaneOf(TFace f) => Geometry.ExactEdges.ShapeOf(GeometryAudit.AuthoritativeSurface(f)) as Geometry.Ssi.Plane;

    static double Gap(TFace f, Vector3d p)
    {
        var sh = Geometry.ExactEdges.ShapeOf(GeometryAudit.AuthoritativeSurface(f));
        switch (sh)
        {
            case Geometry.Ssi.Plane pl: return Math.Abs(Vector3d.Dot(p - pl.P, pl.N.Normalized()));
            case Geometry.Ssi.Cylinder cy: { var w = cy.Axis.Normalized(); var d = p - cy.P; return Math.Abs((d - w * Vector3d.Dot(d, w)).Length - cy.R); }
            case Geometry.Ssi.Sphere sp: return Math.Abs((p - sp.C).Length - sp.R);
        }
        var src = GeometryAudit.AuthoritativeSurface(f);
        if (src == null) return 0;
        try { return (src.PointAt(src.ProjectToUV(p)) - p).Length; } catch { return 0; }
    }

    static readonly bool HealSideDbg = Environment.GetEnvironmentVariable("P3D_HEALSIDEDBG") == "1";
    static readonly bool HealSideOff = Environment.GetEnvironmentVariable("P3D_HEALSIDE") == "0";
    static readonly bool HealSideLoops = Environment.GetEnvironmentVariable("P3D_HEALSIDE") == "loops";
    static readonly bool CapFixOff = Environment.GetEnvironmentVariable("P3D_CAPFIX") == "0";
    static readonly bool FileAccOff = Environment.GetEnvironmentVariable("P3D_HEALFILEACC") == "0";
    static readonly bool EdgeTolOff = Environment.GetEnvironmentVariable("P3D_HEALEDGETOL") == "0";
    const double EdgeTolCap = 0.02;

    public static Report Heal(TSolid b, List<string>? warnings, string label, double fileAccuracy = 0)
    {
        // k182: бюджет — не меньше точности файла (STEP: GLOBAL_UNCERTAINTY; Parasolid: допуски рёбер и вершин), но не больше
        // 0,01 мм — как OCCT при read.precision.mode = File. Мутация P3D_HEALFILEACC=0 — только общий бюджет.
        double budget = Math.Max(ToleranceContext.Current.ImportHeal, FileAccOff ? 0 : Math.Min(fileAccuracy, 0.01));
        if (b.TopologyConvention < TopologyConventions.Version) TopologyConventions.Normalize(b);
        bool changed = false;
        // 1. зазоры вершин
        var facesOf = new Dictionary<TVertex, HashSet<TFace>>(ReferenceEqualityComparer.Instance);
        foreach (var f in b.Faces)
            foreach (var ce in f.Loops.SelectMany(l => l.CoEdges))
                foreach (var v in new[] { ce.Start, ce.End })
                {
                    if (!facesOf.TryGetValue(v, out var s)) facesOf[v] = s = new HashSet<TFace>(ReferenceEqualityComparer.Instance);
                    s.Add(f);
                }
        double maxGap = 0; int snapped = 0; string? problem = null;
        var touched = new HashSet<TFace>(ReferenceEqualityComparer.Instance);
        foreach (var (v, fs) in facesOf)
        {
            double g = fs.Max(f => Gap(f, v.P));
            maxGap = Math.Max(maxGap, g);
            if (g <= 1e-9) continue;
            if (g > budget) { problem ??= $"a vertex is {g:G3} mm off its faces (budget {budget:G3} mm) at ({v.P.X:0.###}, {v.P.Y:0.###}, {v.P.Z:0.###}), faces {string.Join("/", fs.Select(x => $"{GeometryAudit.AuthoritativeSurface(x)?.GetType().Name}:{Gap(x, v.P):G3}"))}"; continue; }
            var pls = fs.Select(PlaneOf).ToList();
            var edges = b.Edges.Where(e => ReferenceEquals(e.V0, v) || ReferenceEquals(e.V1, v)).ToList();
            if (pls.Any(x => x == null) || edges.Any(e => e.Curve is not LineCurve3)) { v.Tolerance = Math.Max(v.Tolerance, g); continue; }
            Geometry.Ssi.Plane[]? basis = null;
            for (int x = 0; x < pls.Count && basis == null; x++)
                for (int y = x + 1; y < pls.Count && basis == null; y++)
                    for (int z = y + 1; z < pls.Count && basis == null; z++)
                        if (Math.Abs(Vector3d.Dot(pls[x]!.N.Normalized(), Vector3d.Cross(pls[y]!.N.Normalized(), pls[z]!.N.Normalized()))) > 1e-6) basis = new[] { pls[x]!, pls[y]!, pls[z]! };
            if (basis == null) { v.Tolerance = Math.Max(v.Tolerance, g); continue; }
            var n1 = basis[0].N.Normalized(); var n2 = basis[1].N.Normalized(); var n3 = basis[2].N.Normalized();
            double d1 = Vector3d.Dot(n1, basis[0].P), d2 = Vector3d.Dot(n2, basis[1].P), d3 = Vector3d.Dot(n3, basis[2].P);
            var x0 = (Vector3d.Cross(n2, n3) * d1 + Vector3d.Cross(n3, n1) * d2 + Vector3d.Cross(n1, n2) * d3) / Vector3d.Dot(n1, Vector3d.Cross(n2, n3));
            if ((x0 - v.P).Length > budget || pls.Any(pl => Math.Abs(Vector3d.Dot(x0 - pl!.P, pl.N.Normalized())) > 1e-9 * Math.Max(1, x0.Length))) { v.Tolerance = Math.Max(v.Tolerance, g); continue; }
            v.P = x0; snapped++; changed = true; touched.UnionWith(fs);
            foreach (var e in edges) { e.Curve = new LineCurve3(e.V0.P, e.V1.P); e.PolylineCache = null; }
        }
        // 2. дыры: контуры свободных рёбер
        int filled = 0;
        var free = b.Edges.Where(e => e.CoEdges.Count == 1).ToList();
        var byStart = new Dictionary<TVertex, List<TCoEdge>>(ReferenceEqualityComparer.Instance);
        foreach (var e in free) { var c = e.CoEdges[0]; if (!byStart.TryGetValue(c.End, out var l)) byStart[c.End] = l = new(); l.Add(c); }
        var usedC = new HashSet<TCoEdge>(ReferenceEqualityComparer.Instance);
        foreach (var e in free)
        {
            var c0 = e.CoEdges[0]; if (usedC.Contains(c0)) continue;
            var chain = new List<TCoEdge>(); var c = c0; bool closed = false;
            for (int guard = 0; guard < 10000; guard++)
            {
                chain.Add(c); usedC.Add(c);
                // новая грань обходит ребро наоборот: от c.End к c.Start; следующий — свободный, начинающийся (в новом обходе) в c.Start
                if (!byStart.TryGetValue(c.Start, out var nx) || nx.Count != 1) break;
                c = nx[0];
                if (ReferenceEquals(c, c0)) { closed = true; break; }
                if (usedC.Contains(c)) break;
            }
            if (!closed) { problem ??= "open edges do not form a closed loop"; continue; }
            var pts = new List<Vector3d>();
            foreach (var ce in Enumerable.Reverse(chain)) { var t = new List<Vector3d>(); ce.Edge.Curve.Tessellate(t, true); if (!ce.Reversed) t.Reverse(); pts.AddRange(t); }
            Vector3d area = Vector3d.Zero; var cen = pts.Aggregate(Vector3d.Zero, (s, q) => s + q) / pts.Count;
            for (int i = 0; i < pts.Count; i++) area += Vector3d.Cross(pts[i] - cen, pts[(i + 1) % pts.Count] - cen);
            if (area.LengthSquared < 1e-24) { problem ??= "a hole loop has no area"; continue; }
            var n = area.Normalized();
            if (pts.Any(q => Math.Abs(Vector3d.Dot(q - cen, n)) > budget)) { problem ??= "a hole loop is not planar within the budget"; continue; }
            // контур — отверстие в грани той же плоскости (выпала стенка отверстия, а не плоская грань): закрывать нечем
            if (chain.Any(ce => ce.Loop?.Face is { } nf && PlaneOf(nf) is { } npl && Math.Abs(Math.Abs(Vector3d.Dot(npl.N.Normalized(), n)) - 1) < 1e-9 && Math.Abs(Vector3d.Dot(cen - npl.P, npl.N.Normalized())) <= budget))
            { problem ??= "an opening lies in the plane of its neighbour face (a missing non-planar face)"; continue; }
            var face = new TFace { Surface = new PlaneSurface(Frame3.FromNormal(cen, n)), Reversed = false, Tag = "import:filled" };
            var loop = face.AddLoop(true);
            foreach (var ce in Enumerable.Reverse(chain)) loop.Add(ce.Edge, !ce.Reversed);
            b.Shells[0].Add(face);
            filled++; changed = true; touched.Add(face);
        }
        int openLeft = b.Edges.Count(e => e.CoEdges.Count == 1);
        if (changed)
        {
            foreach (var f in touched) { f.InteriorHint = null; foreach (var ce in f.Loops.SelectMany(l => l.CoEdges)) { ce.PCurve = null; ce.PCurveDeviation = 0; } }
            b.DisplayMeshKey = null;
            TopologyConventions.Normalize(b);
            // разметка — только у тронутых граней (у прочих — прежняя сетка как донор)
            StepImport.MeshFacesFromLoops(b, null, "Heal", f => touched.Contains(f) ? null : f.Surface as FacetedSurface);
        }
        // k184: СТОРОНА ГРАНИ — ПО ОБХОДУ КОНТУРОВ. После соглашения контуры всей оболочки согласованы (каждое ребро — в разные
        // стороны у двух граней) и ориентированы по якорю; грань лежит слева от обхода. Треугольник сетки у края проходит
        // сторону края в том же направлении, что и полуребро; если у грани большинство таких сторон пройдено навстречу —
        // её фасеты вывернуты (кардан 60075K97: стенка поперечного отверстия против кусочков расточки). Мутация P3D_HEALSIDE=0.
        // k184: сторона — по соседям в сетке (обход фасет оболочки, как ShapeFix_Shell в OCCT), а не по контурам: у части
        // деталей контуры граней обходят их навстречу верным фасетам (крестовина 2455K22, опора 60945K17, плита 8856N18,
        // ограждение 92735T25 — грани разворачивались зря). Прежний способ — P3D_HEALSIDE=loops.
        if (!HealSideOff && !HealSideLoops)
        {
            int before = StepImport.OrientShellCount(b);
            if (before > 0) { b.DisplayMeshKey = null; warnings?.Add($"Import: {label}: {before} face side(s) turned to match the neighbours."); }
        }
        if (!HealSideOff && HealSideLoops)
        {
            static (long, long, long) K(Vector3d p) => ((long)Math.Round(p.X * 1e5), (long)Math.Round(p.Y * 1e5), (long)Math.Round(p.Z * 1e5));
            int flippedSides = 0;
            foreach (var f in b.Faces.ToList())
            {
                if (f.Surface is not FacetedSurface fs || fs.Facets.Count == 0) continue;
                var dirEdges = new Dictionary<((long, long, long), (long, long, long)), int>();
                foreach (var t in fs.Facets)
                    foreach (var (p0, p1) in new[] { (t.Item1, t.Item2), (t.Item2, t.Item3), (t.Item3, t.Item1) })
                        dirEdges[(K(p0), K(p1))] = 1;
                int with = 0, against = 0;
                foreach (var ce in f.Loops.SelectMany(l => l.CoEdges))
                {
                    List<Vector3d> pts; try { pts = Tess.ExactFaceMesher.EdgePoints(ce.Edge); } catch { continue; }
                    if (pts.Count < 2) continue;
                    if (ce.Reversed) { pts = new List<Vector3d>(pts); pts.Reverse(); }
                    for (int i = 0; i + 1 < pts.Count; i++)
                    {
                        var ka = K(pts[i]); var kb = K(pts[i + 1]);
                        if (dirEdges.ContainsKey((ka, kb))) with++; else if (dirEdges.ContainsKey((kb, ka))) against++;
                    }
                }
                if (HealSideDbg && (against > 0 || with < 3)) warnings?.Add($"HEALSIDE {f.Tag}: with {with}, against {against}, facets {fs.Facets.Count}, loops {f.Loops.Count}");
                if (against <= with || against < 3) continue;
                var list = fs.Facets.ToList(); var n = Vector3d.Zero;
                foreach (var t in list) n += Vector3d.Cross(t.Item3 - t.Item1, t.Item2 - t.Item1);
                var fl = new FacetedSurface(fs.Source, n.LengthSquared > 1e-18 ? n.Normalized() : Vector3d.UnitZ) { FromLoops = fs.FromLoops };
                foreach (var t in list) fl.Facets.Add((t.Item1, t.Item3, t.Item2));
                f.Surface = fl;
                flippedSides++;
            }
            if (flippedSides > 0) { b.DisplayMeshKey = null; warnings?.Add($"Import: {label}: {flippedSides} face side(s) turned to match the loops."); }
        }
        // k184: щепки у края с обратным обходом — и в фасетах прочитанной грани (их сетка идёт в показ и проверку как есть;
        // стартер 7595K62: отверстие, касающееся контура плоской грани в вершине). Мутация P3D_CAPFIX=0.
        if (!CapFixOff)
        {
            int capFaces = 0;
            foreach (var f in b.Faces.ToList())
            {
                if (f.Surface is not FacetedSurface fs || fs.Facets.Count < 2) continue;
                var P = new List<Vector3d>(fs.Facets.Count * 3); var T = new List<int>(fs.Facets.Count * 3);
                foreach (var t in fs.Facets) { T.Add(P.Count); P.Add(t.Item1); T.Add(P.Count); P.Add(t.Item2); T.Add(P.Count); P.Add(t.Item3); }
                if (!Tess.ExactFaceMesher.FixBoundaryCaps(P, T)) continue;
                var fl = new FacetedSurface(fs.Source, fs.FallbackNormal) { FromLoops = fs.FromLoops };
                for (int i = 0; i + 2 < T.Count; i += 3) fl.Facets.Add((P[T[i]], P[T[i + 1]], P[T[i + 2]]));
                f.Surface = fl; capFaces++;
            }
            if (capFaces > 0) { b.DisplayMeshKey = null; warnings?.Add($"Import: {label}: boundary slivers turned on {capFaces} face(s)."); }
        }
        // k185: ДОПУСК РЁБЕР ПО ФАКТУ (как ShapeFix_Edge::FixSameParameter в OCCT и допусковые рёбра Parasolid): кривая ребра
        // отходит от смежных поверхностей на микроны — сотые доли мм (приближённая поверхность скругления по сечениям, сплайн
        // кривой пересечения по карте XT) — ребру ставится допуск по измеренному отходу, если он не больше 0,02 мм. Больший
        // отход — брак, как прежде. Мутация P3D_HEALEDGETOL=0.
        // только при зазорах вершин в пределах бюджета: сверх бюджета — брак, о котором сообщается (KRN09-IGES-IMPORT-HEAL)
        if (!EdgeTolOff && maxGap <= budget)
        {
            var audit = GeometryAudit.Of(b);
            int raised = 0; double maxDev = 0;
            var byId = b.Edges.GroupBy(x => x.Id).ToDictionary(g => g.Key, g => g.First());
            foreach (var eg in audit.Edges)
            {
                if (eg.Level != GeometryLevel.Inconsistent) continue;
                double dev = Math.Max(double.IsNaN(eg.OnA) ? 0 : eg.OnA, double.IsNaN(eg.OnB) ? 0 : eg.OnB);
                if (dev > EdgeTolCap || !byId.TryGetValue(eg.Edge, out var ed)) continue;
                ed.Tolerance = Math.Max(ed.Tolerance, 0.6 * dev); raised++; maxDev = Math.Max(maxDev, dev);
            }
            if (raised > 0) warnings?.Add($"Import: {label}: tolerance of {raised} edge(s) set from the curve-to-surface gap (max {maxDev:G3} mm).");
        }
        var vr = SolidValidator.ValidateBRep(b);
        bool overBudget = maxGap > budget;
        bool valid = vr.IsValid && openLeft == 0 && !overBudget && problem == null;
        if (!valid) problem ??= openLeft > 0 ? $"{openLeft} open edge(s)" : vr.Summary();
        var rep = new Report(maxGap, snapped, filled, openLeft, valid, valid ? null : problem);
        warnings?.Add($"Import: {label}: {rep}.");
        return rep;
    }
}
